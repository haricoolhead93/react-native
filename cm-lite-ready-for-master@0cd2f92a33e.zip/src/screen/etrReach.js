import { Text, View } from "react-native";

export default function etrReach() {
  return <Text>Hi etr Reach Page</Text>;
}
