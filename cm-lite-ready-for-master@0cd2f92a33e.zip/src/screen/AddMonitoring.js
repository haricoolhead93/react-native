import React from "react";

import { View } from "native-base";

export default function AddMonitoring() {
  return <View>HI</View>;
}
