import { Text, View } from "react-native";

export default function Reinforce() {
  return <Text>Hi Reinforce.</Text>;
}
